export const metadata = { title: 'kakozbyszek', description: 'Sklep' };
export default function RootLayout({ children }) {
  return (
    <html lang="pl">
      <body>{children}</body>
    </html>
  );
}
