export default function Home() {
  return (
    <main style={{background:'#000',color:'#fff',minHeight:'100vh',padding:'40px'}}>
      <h1 style={{fontSize:'40px'}}>kakozbyszek – sklep</h1>
      <p>Strona działa! Możesz teraz dodać produkty itp.</p>
    </main>
  );
}
